# SentinelCore Web

A futuristic web-based prototype of SentinelCore, simulating:

- AES-256 File Encryption/Decryption
- Firewall Port Control Simulation
- Mock Antivirus Scanning

## Technologies Used

- HTML5
- CSS3
- JavaScript (ES6)

## How to Run

1. Clone the repository:
