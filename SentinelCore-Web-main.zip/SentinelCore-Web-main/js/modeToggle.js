function switchToTerminal() {
  window.location.href = "terminal.html";
}

function switchToFuturistic() {
  window.location.href = "dashboard.html";
}
