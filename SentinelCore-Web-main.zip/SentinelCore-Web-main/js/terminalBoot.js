document.addEventListener("DOMContentLoaded", () => {
  const loader = document.getElementById("boot-loader");
  setTimeout(() => loader.style.display = "none", 1500);
});
